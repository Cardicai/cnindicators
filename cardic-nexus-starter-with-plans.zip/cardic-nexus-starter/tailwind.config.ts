import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          50: "#eef6ff",
          100: "#d9eaff",
          200: "#b6d4ff",
          300: "#84b6ff",
          400: "#4f93ff",
          500: "#2f77f5",
          600: "#1f5bd1",
          700: "#1b4aaa",
          800: "#1a3e89",
          900: "#18366f",
        },
      },
      boxShadow: {
        glow: "0 0 40px rgba(47,119,245,0.25)",
      },
    },
  },
  plugins: [],
};
export default config;