

## Notes
- Replace `https://formspree.io/f/YOUR_FORM_ID` with your Formspree form endpoint (or use another service).
- Update crypto addresses in `app/payment/page.tsx` with your real wallets.
- To automate payments later, integrate Coinbase Commerce or NOWPayments.
