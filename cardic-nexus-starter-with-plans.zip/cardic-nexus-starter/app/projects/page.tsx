import ProjectCard from "@/components/ProjectCard";
import Link from "next/link";
import { projects } from "@/data/projects";

export default function ProjectsPage() {
  return (
    <section className="container py-12">
      <div className="flex items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl md:text-4xl font-bold">Projects</h1>
          <p className="text-slate-300 mt-2">
            Indicators, Expert Advisors (EAs), and Bots — organized for clarity.
          </p>
        </div>
      </div>

      <div className="mt-8 grid md:grid-cols-2 gap-6">
        {projects.map((p) => (
          <ProjectCard
            key={p.title}
            title={p.title}
            category={p.category as any}
            version={p.version}
            description={p.description}
            actions={
              <div className="flex gap-3">
                <Link className="btn-primary" href={p.links.demo}>Demo</Link>
                <Link className="px-4 py-2 rounded-2xl border border-slate-700" href={p.links.docs}>Docs</Link>
              </div>
            }
          />
        ))}
      </div>
    </section>
  );
}