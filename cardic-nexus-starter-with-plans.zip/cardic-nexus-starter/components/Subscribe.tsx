export default function Subscribe() {
  return (
    <form action="https://formspree.io/f/YOUR_FORM_ID" method="POST" className="flex gap-2 max-w-xl mx-auto">
      <input type="email" name="email" placeholder="you@domain.com" required className="flex-1 rounded-2xl px-4 py-3 bg-slate-900/40 border border-slate-700 focus:outline-none" />
      <button type="submit" className="btn-primary">Subscribe</button>
    </form>
  );
}
