export default function PaymentPage() {
  return (
    <section className="container py-12 max-w-2xl">
      <h1 className="text-3xl md:text-4xl font-bold">Payment — Crypto</h1>
      <p className="text-slate-300 mt-2">Send payment to any of the addresses below. After payment, copy your transaction hash and email it to Cardic or DM on Telegram/WhatsApp to get access.</p>

      <div className="mt-6 grid gap-4">
        <div className="card p-4">
          <h4 className="font-medium">USDT (ERC20)</h4>
          <p className="text-slate-300 text-sm break-all mt-1">0xDEADBEEFDEADBEEFDEADBEEFDEADBEEFDEADBEEF</p>
        </div>

        <div className="card p-4">
          <h4 className="font-medium">BTC</h4>
          <p className="text-slate-300 text-sm break-all mt-1">bc1qexampleaddress0000000000000000000000</p>
        </div>

        <div className="card p-4">
          <h4 className="font-medium">ETH</h4>
          <p className="text-slate-300 text-sm break-all mt-1">0xEXAMPLEETHADDRESS00000000000000000000000</p>
        </div>

        <div className="card p-4">
          <h4 className="font-medium">Automated Checkout (Optional)</h4>
          <p className="text-slate-300 text-sm mt-1">We can integrate Coinbase Commerce or NOWPayments. For now, payments are manual.</p>
          <p className="text-slate-300 text-sm mt-2">After payment, email your tx hash or DM: <strong>t.me/REALCARDIC</strong></p>
        </div>
      </div>
    </section>
  );
}
