export const plans = [
  {
    id: "free",
    name: "Free",
    price: "Free",
    features: ["CN Pro RSI (Lite)", "Community support", "Basic docs"]
  },
  {
    id: "pro",
    name: "Pro",
    price: "50 USDT / month",
    features: ["Full CN Pro RSI", "Cardic Heat Basic", "Email support", "Priority docs"]
  },
  {
    id: "premium",
    name: "Premium",
    price: "150 USDT / month",
    features: ["All indicators + EA", "Early access", "Private support", "Strategy calls"]
  }
] as const;
