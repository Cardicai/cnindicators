"use client";
import Link from "next/link";
import Image from "next/image";
import { Menu } from "lucide-react";
import { useState } from "react";

export default function Navbar() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-50 border-b border-slate-800/60 bg-slate-950/60 backdrop-blur">
      <div className="container flex items-center justify-between py-3">
        <Link href="/" className="flex items-center gap-3">
          <Image src="/logo.svg" alt="Cardic Nexus" width={140} height={30} priority />
        </Link>
        <nav className="hidden md:flex items-center gap-6 text-sm text-slate-300">
          <Link className="hover:text-white" href="/projects">Projects</Link>\n              <Link className="hover:text-white" href="/plans">Plans</Link>\n              <Link className="hover:text-white" href="/payment">Payment</Link>
          <Link className="hover:text-white" href="/about">About</Link>
          <Link className="hover:text-white" href="/contact">Contact</Link>
          <a className="btn-primary ml-2" href="#join">Join Cardic Nexus</a>
        </nav>
        <button className="md:hidden" onClick={() => setOpen(!open)} aria-label="Menu">
          <Menu />
        </button>
      </div>
      {open && (
        <div className="md:hidden border-t border-slate-800/60 bg-slate-950/80">
          <div className="container py-3 flex flex-col gap-3 text-sm">
            <Link onClick={() => setOpen(false)} href="/projects">Projects</Link>
            <Link onClick={() => setOpen(false)} href="/about">About</Link>
            <Link onClick={() => setOpen(false)} href="/contact">Contact</Link>
            <a onClick={() => setOpen(false)} className="btn-primary w-fit" href="#join">Join Cardic Nexus</a>
          </div>
        </div>
      )}
    </header>
  );
}