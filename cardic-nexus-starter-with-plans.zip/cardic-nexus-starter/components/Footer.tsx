export default function Footer() {
  return (
    <footer className="mt-16 border-t border-slate-800/60">
      <div className="container py-10 grid gap-8 md:grid-cols-3 items-center">
        <div className="space-y-2">
          <h4 className="text-lg font-semibold">Cardic Nexus</h4>
          <p className="text-sm text-slate-400">
            Trading intelligence, indicators, EAs and automation.
          </p>
        </div>
        <div className="text-sm text-slate-400">
          <p>
            Built with ❤️ + focus. Deployed on Vercel.
          </p>
        </div>
        <div className="flex md:justify-end gap-4 text-sm">\n              <a href="mailto:cardic@cardicnexus.com" className="hover:underline">Email</a>
          <a href="https://x.com/CARDICNEXUS" target="_blank" className="hover:underline">X (Twitter)</a>
          <a href="https://t.me/REALCARDIC" target="_blank" className="hover:underline">Telegram</a>
          <a href="https://wa.me/447365718250" target="_blank" className="hover:underline">WhatsApp</a>
        </div>
      </div>
    </footer>
  );
}