import { plans } from "@/data/plans";
import Link from "next/link";

export default function PlansPage() {
  return (
    <section className="container py-12">
      <div className="text-center max-w-3xl mx-auto">
        <h1 className="text-3xl md:text-4xl font-bold">Compare Plans</h1>
        <p className="text-slate-300 mt-2">Simple pricing and plan features — pay via crypto. Start with Free to try.</p>
      </div>

      <div className="mt-8 grid md:grid-cols-3 gap-6">
        {plans.map((p) => (
          <div key={p.id} className="card p-6 flex flex-col">
            <h3 className="text-xl font-semibold">{p.name}</h3>
            <p className="text-slate-300 mt-1">{p.price}</p>
            <ul className="mt-4 space-y-2 text-sm flex-1">
              {p.features.map((f) => (
                <li key={f} className="text-slate-300">• {f}</li>
              ))}
            </ul>
            <div className="mt-4">
              <a className="btn-primary" href="/payment">Choose Plan</a>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-12 max-w-2xl mx-auto card p-6">
        <h4 className="font-semibold">Compare features</h4>
        <p className="text-slate-300 text-sm mt-2">If you'd like to accept automated crypto checkout later, we can integrate Coinbase Commerce or NOWPayments.</p>
      </div>
    </section>
  );
}
