import "./globals.css";
import { ReactNode } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

export const metadata = {
  title: "Cardic Nexus — Trading Intelligence Hub",
  description: "Where trading intelligence, AI and advanced market tools merge.",
  metadataBase: new URL("https://cardic-nexus-starter.vercel.app"),
  openGraph: {
    title: "Cardic Nexus",
    description: "The central hub for indicators, EAs and automation.",
    url: "https://cardic-nexus-starter.vercel.app",
    siteName: "Cardic Nexus",
  },
  twitter: {
    card: "summary_large_image",
    title: "Cardic Nexus",
    description: "The central hub for indicators, EAs and automation."
  }
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-1">{children}</main>
        <Footer />
      </body>
    </html>
  );
}