import Link from "next/link";
import { ArrowRight } from "lucide-react";

export default function Home() {
  return (
    <section className="container py-16 md:py-24">
      {/* Hero */}
      <div className="text-center max-w-3xl mx-auto">
        <h1 className="text-4xl md:text-6xl font-bold leading-tight">
          Where trading intelligence, AI, and advanced tools merge
        </h1>
        <p className="text-slate-300 mt-5">
          Cardic Nexus is the central hub for advanced trading intelligence: indicators,
          Expert Advisors (EAs), and automated bots — built to give traders a professional edge.
        </p>
        <div className="mt-8 flex items-center justify-center gap-4">
          <Link href="/projects" className="btn-primary">
            Explore Projects <ArrowRight className="w-4 h-4" />
          </Link>
          <a href="#join" className="inline-flex items-center gap-2 px-5 py-3 rounded-2xl border border-slate-700 hover:bg-slate-900 transition">
            Learn More
          </a>
        </div>
      </div>

      {/* Featured */}
      <div className="mt-16 grid md:grid-cols-2 gap-6">
        <div className="card p-6">
          <h3 className="text-xl font-semibold">Featured: Cardic Heat 2.1</h3>
          <p className="text-slate-300 mt-2">
            Dynamic liquidity zones with time decay, sentiment overlays, and signal triggers.
          </p>
          <div className="mt-4">
            <Link href="/projects" className="underline">See details</Link>
          </div>
        </div>
        <div className="card p-6">
          <h3 className="text-xl font-semibold">Featured: DR/iDR EA</h3>
          <p className="text-slate-300 mt-2">
            Automated breakout/breach engine with ATR risk and partial TP roadmap.
          </p>
          <div className="mt-4">
            <Link href="/projects" className="underline">See details</Link>
          </div>
        </div>
      </div>

      {/* Join CTA */}
      <div id="join" className="mt-20 card p-8 text-center">
        <h3 className="text-2xl font-semibold">Join Cardic Nexus</h3>
        <p className="text-slate-300 mt-2">
          This is what we’re building. Would you like to join?
        </p>
        <div className="mt-5 flex items-center justify-center gap-4">
          <a className="btn-primary" href="https://wa.me/447365718250" target="_blank">WhatsApp</a>
          <a className="btn-primary" href="https://t.me/REALCARDIC" target="_blank">Telegram</a>
          <a className="btn-primary" href="https://x.com/CARDICNEXUS" target="_blank">X (Twitter)</a>
        </div>
      </div>
    </section>
  );
}