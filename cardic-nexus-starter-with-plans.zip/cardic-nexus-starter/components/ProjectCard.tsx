import { ReactNode } from "react";

export default function ProjectCard({
  title,
  category,
  version,
  description,
  actions,
}: {
  title: string;
  category: "Indicator" | "EA" | "Bot";
  version?: string;
  description: string;
  actions?: ReactNode;
}) {
  return (
    <div className="card p-5 hover:shadow-xl hover:shadow-brand-700/10 transition">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-lg font-semibold">{title}</h3>
        {version ? <span className="badge">v{version}</span> : null}
      </div>
      <p className="text-xs uppercase tracking-wider text-slate-400 mb-2">{category}</p>
      <p className="text-slate-300 mb-4">{description}</p>
      {actions}
    </div>
  );
}