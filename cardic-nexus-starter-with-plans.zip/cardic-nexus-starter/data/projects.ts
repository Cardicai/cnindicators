export const projects = [
  {
    title: "CN Pro RSI",
    category: "Indicator",
    version: "1.4",
    description: "Advanced RSI logic with adaptive zones, divergence engine, and multi-timeframe bias.",
    links: { demo: "#", docs: "#" }
  },
  {
    title: "Cardic Heat",
    category: "Indicator",
    version: "2.1",
    description: "Dynamic liquidity zones + time decay + sentiment overlays + triggers.",
    links: { demo: "#", docs: "#" }
  },
  {
    title: "DR/iDR EA",
    category: "EA",
    version: "0.9",
    description: "Automated breach/breakout entries with ATR-based risk and partial TP.",
    links: { demo: "#", docs: "#" }
  },
  {
    title: "Smart Scalper Bot",
    category: "Bot",
    version: "0.3",
    description: "Event-aware scalper with session filters and volatility guardrails.",
    links: { demo: "#", docs: "#" }
  }
] as const;